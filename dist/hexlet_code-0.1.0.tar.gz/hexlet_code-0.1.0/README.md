### Hexlet tests and linter status:
[![Actions Status](https://github.com/IvanPiskarev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/IvanPiskarev/python-project-49/actions)
<a href="https://codeclimate.com/github/IvanPiskarev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1252b6949d8ac7ea659c/maintainability" /></a>

[![asciicast](https://asciinema.org/a/khwU3yfolHAXumfvtA2nqrfDS.svg)](https://asciinema.org/a/khwU3yfolHAXumfvtA2nqrfDS)
[![asciicast](https://asciinema.org/a/0f28C1ZTXB9NIiv5vnIu4rR9o.svg)](https://asciinema.org/a/0f28C1ZTXB9NIiv5vnIu4rR9o)
[![asciicast](https://asciinema.org/a/5DyIwqUPPZNWh0rAGynDAzNQ8.svg)](https://asciinema.org/a/5DyIwqUPPZNWh0rAGynDAzNQ8)
[![asciicast](https://asciinema.org/a/v3tv2P46cH890rcomRgGKu0BL.svg)](https://asciinema.org/a/v3tv2P46cH890rcomRgGKu0BL)
[![asciicast](https://asciinema.org/a/zrXvJWOgc5ANUp8BcR9VFkWOQ.svg)](https://asciinema.org/a/zrXvJWOgc5ANUp8BcR9VFkWOQ)
