### Hexlet tests and linter status:
[![Actions Status](https://github.com/IvanPiskarev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/IvanPiskarev/python-project-49/actions)
<a href="https://codeclimate.com/github/IvanPiskarev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1252b6949d8ac7ea659c/maintainability" /></a>